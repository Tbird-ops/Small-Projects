import random as rand

# Setup 
topics = []
wdlength = []
let_req = []
current_red = ""
current_blue = ""
current_yellow = ""

# Functions
def read_yellow():
  yellow_card = open("yellow.txt", "r")

  for line in yellow_card:
    topic = ""
    index = 0

    while (line[index] != "\n"):
      topic = topic + line[index]
      index += 1
    
    topics.append(topic)

def read_blue():
  blue_card = open("blue.txt", "r")

  for line in blue_card:
    length = ""
    index = 0

    while (line[index] != "\n"):
      length = length + line[index]
      index += 1
    
    wdlength.append(length)

def read_red():
  red_card = open("red.txt", "r")

  for line in red_card:
    letters = ""
    index = 0

    while (line[index] != "\n"):
      letters = letters + line[index]
      index += 1
    
    let_req.append(letters)

def select_red():
  global current_red
  current_red = rand.choice(let_req)
  print("Red: " + current_red)
  let_req.remove(current_red)

def select_blue():
  global current_blue
  current_blue = rand.choice(wdlength)
  print("Blue: " + current_blue)
  wdlength.remove(current_blue)

def select_yellow():
  global current_yellow
  current_yellow = rand.choice(topics)
  print("\nYellow: " + current_yellow)
  topics.remove(current_yellow)

def main():
  read_yellow()
  read_blue()
  read_red()
  select_yellow()
  select_blue()
  select_red()

# TODO: Add current card to a player when they win a round

# Initialize
print("\nWelcome to Quicktionary!\n")
main()
while True:
  card_swap = input("What card would you like to take? (yellow/blue/red) ").lower()
  if card_swap == "yellow":
    select_yellow()
    print("Blue: " + current_blue)
    print("Red: " + current_red)
  elif card_swap == "blue":
    print("\nYellow: " + current_yellow)
    select_blue()
    print("Red: " + current_red)
  elif card_swap == "red":
    print("\nYellow: " + current_yellow)
    print("Blue: " + current_blue)
    select_red()
  elif card_swap == "quit":
    break
  else:
    print("\nYellow: " + current_yellow)
    print("Blue: " + current_blue)
    print("Red: " + current_red)


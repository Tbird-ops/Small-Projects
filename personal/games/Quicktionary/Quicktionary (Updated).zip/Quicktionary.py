import random as rand

'''Setup'''

# Variables
players = {} # Player Stats
topics = [] # Yellow Cards
wdlength = [] # Blue Cards
let_req = [] # Red Cards
current_red = ""
current_blue = ""
current_yellow = ""
round_number = 1

# Create the players
num_player = int(input("How many players? "))
for player in range(num_player):
  name = input("What is player {}'s name? ".format(player+1))
  players[player] = {'name' : name, 'score' : 0}

# Analyse the Yellow Card contents and produce the deck
yellow_card = open("yellow.txt", "r")
for line in yellow_card:
  topic = ""
  index = 0
  while (line[index] != "\n"):
    topic = topic + line[index]
    index += 1
  topics.append(topic)
yellow_card.close()

# Analyse the Blue Card contents and produce the deck
blue_card = open("blue.txt", "r")
for line in blue_card:
  length = ""
  index = 0
  while (line[index] != "\n"):
    length = length + line[index]
    index += 1
  wdlength.append(length)
blue_card.close()

# Analyse the Red Card contents and produce the deck
red_card = open("red.txt", "r")
for line in red_card:
  letters = ""
  index = 0
  while (line[index] != "\n"):
    letters = letters + line[index]
    index += 1
  let_req.append(letters)
red_card.close()


'''Functions'''

# Update the player score value
def update_score(card_swap, winner):
  global players
  if card_swap[0] == "y":
    players[winner]['score'] += 1
  elif card_swap[0] == "b":
    players[winner]['score'] += 1
  elif card_swap[0] == "r":
    players[winner]['score'] += 1

# Display the player scores to the console
def display_score():
  for player in players.values():
    print(player.get('name'), player.get('score'))
    check = player.get('score')
    if check == 2:
      print("\nWinner!", player.get('name') + "\n")
      return False

# select new cards
def select_red():
  global current_red
  current_red = rand.choice(let_req)
  print("Red: " + current_red)
  let_req.remove(current_red)

def select_blue():
  global current_blue
  current_blue = rand.choice(wdlength)
  print("Blue: " + current_blue)
  wdlength.remove(current_blue)

def select_yellow():
  global current_yellow
  current_yellow = rand.choice(topics)
  print("\nYellow: " + current_yellow)
  topics.remove(current_yellow)

# if wanted, repeat game
def repeat():
  global round_number
  repeat = input("Would you like to play again? ").lower()
  if repeat[0] == "y":
    print("\n\n")
    round_number = 0
    for player in players.values():
      player['score'] = 0
    main()

# Main Game code
def main():

  global round_number

  select_yellow()
  select_blue()
  select_red()

  while True:
    print("ROUND NUMBER:", round_number)

    winner = int(input("Which player won? (player number) ")) - 1
    card_swap = input("What card would you like to take? (yellow/blue/red) ").lower()

    update_score(card_swap, winner)

    if card_swap[0] == "y":
      select_yellow()
      print("Blue: " + current_blue)
      print("Red: " + current_red)
      round_number += 1

    elif card_swap[0] == "b":
      print("\nYellow: " + current_yellow)
      select_blue()
      print("Red: " + current_red)
      round_number += 1

    elif card_swap[0] == "r":
      print("\nYellow: " + current_yellow)
      print("Blue: " + current_blue)
      select_red()
      round_number += 1

    elif card_swap == "quit":
      break

    else:
      print("\nYellow: " + current_yellow)
      print("Blue: " + current_blue)
      print("Red: " + current_red)

    if display_score() == False:
      break
  repeat()

'''Initialize!'''

print("\nWelcome to Quicktionary!\n")
main()
